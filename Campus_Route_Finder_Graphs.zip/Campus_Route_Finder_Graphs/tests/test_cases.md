# Test Cases

Run the application and select menu option `7` to execute the built-in tests.

| ID | Scenario | Source | Destination | Expected result |
|---|---|---|---|---|
| TC-01 | Direct route | Main Gate | Parking | BFS returns `Main Gate -> Parking`, 1 edge |
| TC-02 | Multi-stop route | Main Gate | Auditorium | BFS returns `Main Gate -> Block 1 -> Block 2 -> Auditorium`, 3 edges |
| TC-03 | Unreachable destination | Main Gate | Hostel | BFS reports that no route exists |

## Additional manual checks

1. Select DFS from Main Gate. It should print the eight locations in the main connected component.
2. Select the reachability report from Main Gate. Sports Complex and Hostel should be listed as disconnected from Main Gate.
3. Select the reachability report from Sports Complex. Sports Complex and Hostel should be reachable; the other eight locations should be listed as disconnected from that starting point.
4. Try entering a letter or a number outside the menu range. The program should show an invalid-input message and ask again.
