# Campus Route Finder Using Graphs

**DSA Mini Project – PPF Week 9**

A menu-driven C++17 application that models campus locations as vertices and roads/paths as undirected edges. It demonstrates an adjacency list, adjacency matrix, Breadth-First Search (BFS), Depth-First Search (DFS), shortest-path reconstruction, reachability, disconnected locations, and test cases.

## Features

1. Ten campus locations are represented as graph vertices.
2. Roads are represented using an undirected adjacency list.
3. Displays an adjacency matrix for comparison.
4. BFS finds a route with the minimum number of edges in this unweighted graph.
5. DFS displays all locations reachable from a selected starting point.
6. A reachability report identifies locations not reachable from the selected start.
7. Includes three automated test cases: direct route, multi-stop route, and unreachable destination.
8. Menu input is validated.

## Campus map used

The first eight locations are connected as the main campus area. Sports Complex and Hostel form a second, separate component. This deliberate disconnected component makes it possible to demonstrate and test unreachable destinations.

| Number | Location |
|---:|---|
| 1 | Main Gate |
| 2 | Library |
| 3 | Block 1 |
| 4 | Block 2 |
| 5 | Cafeteria |
| 6 | Auditorium |
| 7 | Parking |
| 8 | Lab |
| 9 | Sports Complex |
| 10 | Hostel |

## Requirements

- A C++ compiler supporting C++17 (GCC, MinGW-w64, or a recent Visual Studio compiler).

## Compile and run

### Windows (PowerShell / VS Code terminal)

Open the project folder in the terminal and run:

```powershell
g++ -std=c++17 -Wall -Wextra -pedantic src/campus_route_finder.cpp -o campus_route_finder.exe
.\campus_route_finder.exe
```

If `g++` is not recognized, install a C++ compiler such as MinGW-w64 and add its `bin` directory to PATH.

### Linux / macOS

```bash
g++ -std=c++17 -Wall -Wextra -pedantic src/campus_route_finder.cpp -o campus_route_finder
./campus_route_finder
```

## Menu

1. Display all campus locations
2. Display adjacency list
3. Display adjacency matrix
4. Find shortest route using BFS
5. Display reachable locations using DFS
6. Display reachable and disconnected locations
7. Run automated test cases
8. Exit

When prompted for a location, enter its number from the displayed list.

## Algorithms and complexity

Let `V` be the number of vertices (locations) and `E` be the number of undirected edges (roads).

| Operation | Time complexity | Extra space |
|---|---|---|
| Build adjacency list | O(V + E) | O(V + E) |
| BFS | O(V + E) | O(V) |
| DFS | O(V + E) | O(V) |
| Display adjacency list | O(V + E) | O(1) beyond output |
| Build/display adjacency matrix | O(V²) | O(V²) for matrix representation |

BFS uses a queue and a parent array. Once the destination is reached, the parent links are followed backwards and reversed to reconstruct the route. In an unweighted graph, BFS returns a path containing the minimum number of edges.

DFS uses recursion and a visited array. It explores one branch as far as possible before returning to another branch.

### Adjacency list vs adjacency matrix

| Feature | Adjacency list | Adjacency matrix |
|---|---|---|
| Storage | O(V + E) | O(V²) |
| Check whether an edge exists | O(degree of vertex) in this implementation | O(1) |
| Iterate through neighbours | O(degree of vertex) | O(V) |
| Best suited for | Sparse graphs | Dense graphs / frequent edge checks |

This project uses an adjacency list for BFS and DFS because it visits only the actual neighbours of each vertex. The matrix is displayed as an optional representation comparison.

## Test cases

The executable includes these tests in menu option 7.

| Test | Source | Destination | Expected result |
|---|---|---|---|
| 1. Direct route | Main Gate | Parking | Route with 1 edge |
| 2. Multi-stop route | Main Gate | Auditorium | Shortest route with 3 edges |
| 3. Unreachable destination | Main Gate | Hostel | No route exists |

The BFS route for the multi-stop test is deterministic for the adjacency order in the source code: `Main Gate -> Block 1 -> Block 2 -> Auditorium`.

See `tests/test_cases.md` and `docs/sample_outputs.txt` for expected output examples.

## Project structure

```text
Campus_Route_Finder_Graphs/
├── src/
│   └── campus_route_finder.cpp
├── docs/
│   ├── project_report.md
│   ├── sample_outputs.txt
│   └── screenshot_guide.md
├── tests/
│   └── test_cases.md
└── README.md
```

## Screenshots for submission

Run the program and capture screenshots of:
1. The list of all ten locations.
2. The adjacency list (and optionally the matrix).
3. A BFS direct route.
4. A BFS multi-stop route.
5. A BFS unreachable destination.
6. DFS traversal and the reachability/disconnected report.
7. The automated test results.

Save your actual screenshots in a folder named `screenshots/` before submitting. A guide is in `docs/screenshot_guide.md`.

## GitHub submission

Create a new GitHub repository, for example `Campus-Route-Finder-Graphs`. Upload the contents of this project folder (not just the ZIP file), including source code, README, report, tests, and your screenshots. Add the repository URL to your college submission form.

## Academic note

Review the code and report, run the program yourself, and make sure you can explain BFS, DFS, the parent array, and the complexity during your viva. Update the sample campus locations or connections if your instructor expects your actual campus map.
