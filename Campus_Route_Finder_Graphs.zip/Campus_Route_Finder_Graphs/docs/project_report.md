# Project Report: Campus Route Finder Using Graphs

## 1. Introduction

The Campus Route Finder is a Data Structures and Algorithms mini project. It models campus locations as vertices and the paths between locations as edges. A user can inspect the graph, find a shortest route, explore reachable locations, and identify locations that are disconnected from a selected starting point.

## 2. Objectives

- Represent at least eight campus locations using a graph.
- Implement the graph using an adjacency list.
- Demonstrate an adjacency matrix as an alternative representation.
- Use BFS to find a minimum-edge route in an unweighted graph.
- Use DFS to explore reachable locations.
- Identify disconnected locations.
- Test direct, multi-stop, and unreachable route cases.
- Explain algorithm and representation complexity.

## 3. Graph design

The graph is undirected: if a path connects location A to location B, both locations appear in each other's neighbour lists. The program contains ten vertices:

1. Main Gate
2. Library
3. Block 1
4. Block 2
5. Cafeteria
6. Auditorium
7. Parking
8. Lab
9. Sports Complex
10. Hostel

The first eight vertices form the main campus component. Sports Complex and Hostel form a separate component connected to each other. This gives the program a realistic way to demonstrate disconnected locations and an unreachable destination.

The graph is stored as `vector<vector<int>>`. Each vector contains the indices of the neighbouring vertices. The graph is undirected, so adding an edge adds each endpoint to the other's neighbour list.

## 4. Algorithms used

### 4.1 Breadth-First Search (BFS)

BFS explores vertices level by level, using a queue. It first visits the source, then its direct neighbours, then the neighbours at the next distance level.

The program maintains:
- `visited`: prevents a vertex from being visited more than once.
- `parent`: stores the vertex from which each vertex was first discovered.
- `queue`: stores discovered vertices waiting to be explored.

After BFS, the program reconstructs the path by following `parent` from the destination back to the source, then reverses the sequence. Because every edge is treated as having equal cost, BFS returns a route with the minimum number of edges.

**Time complexity:** O(V + E) using an adjacency list.

**Auxiliary space complexity:** O(V) for the visited array, parent array, and queue, excluding the graph itself and the returned path.

### 4.2 Depth-First Search (DFS)

DFS explores one neighbour as deeply as possible before backtracking. This implementation uses recursion and a visited array. It prints every location reachable from the selected starting point.

**Time complexity:** O(V + E) using an adjacency list.

**Auxiliary space complexity:** O(V) for the visited array and recursion stack in the worst case.

### 4.3 Reachability and disconnected locations

A BFS traversal from the selected starting point marks every reachable vertex. Any vertex left unvisited is disconnected from that particular starting point. In this sample graph, starting at Main Gate leaves Sports Complex and Hostel unvisited.

## 5. Adjacency list and adjacency matrix comparison

| Point | Adjacency list | Adjacency matrix |
|---|---|---|
| Space | O(V + E) | O(V²) |
| Neighbour traversal | O(degree of vertex) | O(V) |
| Edge lookup | O(degree of vertex) in this implementation | O(1) |
| Suitable graph | Usually sparse | Often dense |

The project uses the adjacency list for its main algorithms because it stores only existing roads and supports efficient neighbour traversal. The matrix is included to demonstrate the alternative representation.

## 6. Sample test cases

| Test case | Source | Destination | Expected output |
|---|---|---|---|
| Direct route | Main Gate | Parking | A route with one edge |
| Multi-stop route | Main Gate | Auditorium | A shortest route with three edges |
| Unreachable destination | Main Gate | Hostel | No route exists |

Expected BFS multi-stop route with the adjacency order in this program:

`Main Gate -> Block 1 -> Block 2 -> Auditorium`

The route has three edges. There may be more than one shortest route in a graph; BFS returns one of the minimum-edge routes.

## 7. Conclusion

The project demonstrates graph representation and traversal using C++. BFS is used to find a minimum-edge route in an unweighted graph, while DFS is used to explore reachable locations. The reachability report identifies vertices outside the selected source's connected component. The project also compares adjacency-list and adjacency-matrix representations and includes test cases for direct, multi-stop, and unreachable routes.

## 8. Possible future improvements

- Allow users to add or remove campus locations and paths.
- Use weighted edges to represent distance or walking time and apply Dijkstra's algorithm.
- Add a graphical campus map.
- Save the campus graph to a file so that changes remain available after restarting the program.
