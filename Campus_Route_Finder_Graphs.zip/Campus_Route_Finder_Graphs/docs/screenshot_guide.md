# Screenshot Guide

The project brief asks for screenshots of graph input/representation, BFS route, DFS traversal, and test-case outputs.

After compiling and running the program, capture genuine screenshots from your own terminal:

1. **Locations:** choose menu option 1.
2. **Adjacency list:** choose menu option 2.
3. **BFS direct route:** choose option 4, source 1 (Main Gate), destination 7 (Parking).
4. **BFS multi-stop route:** choose option 4, source 1 (Main Gate), destination 6 (Auditorium).
5. **Unreachable route:** choose option 4, source 1 (Main Gate), destination 10 (Hostel).
6. **DFS traversal:** choose option 5, starting location 1 (Main Gate).
7. **Disconnected locations:** choose option 6, starting location 1 (Main Gate).
8. **Automated tests:** choose option 7.

Save the images in a new `screenshots/` folder. Do not use the illustrative text in `sample_outputs.txt` as a substitute for actual screenshots if your instructor requires screenshots of a running program.
