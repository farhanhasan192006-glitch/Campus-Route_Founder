#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <string>
#include <limits>
#include <algorithm>

using namespace std;

class CampusGraph {
private:
    vector<string> locations;
    vector<vector<int>> adj;

    void dfsVisit(int current, vector<bool>& visited) const {
        visited[current] = true;
        cout << locations[current] << '\n';

        for (int neighbour : adj[current]) {
            if (!visited[neighbour]) {
                dfsVisit(neighbour, visited);
            }
        }
    }

public:
    CampusGraph() {
        locations = {
            "Main Gate", "Library", "Block 1", "Block 2", "Cafeteria",
            "Auditorium", "Parking", "Lab", "Sports Complex", "Hostel"
        };

        adj.resize(locations.size());

        // The first eight locations form the main connected campus area.
        addRoad(0, 1);
        addRoad(0, 2);
        addRoad(0, 6);
        addRoad(1, 2);
        addRoad(1, 4);
        addRoad(2, 3);
        addRoad(2, 7);
        addRoad(3, 4);
        addRoad(3, 5);
        addRoad(4, 5);
        addRoad(5, 7);

        // Sports Complex and Hostel form a separate component for testing
        // disconnected locations.
        addRoad(8, 9);
    }

    int size() const {
        return static_cast<int>(locations.size());
    }

    const string& getLocation(int index) const {
        return locations[index];
    }

    void addRoad(int a, int b) {
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    void displayLocations() const {
        cout << "\n--- Campus Locations ---\n";
        for (int i = 0; i < size(); ++i) {
            cout << i + 1 << ". " << locations[i] << '\n';
        }
    }

    void displayAdjacencyList() const {
        cout << "\n--- Adjacency List ---\n";
        for (int i = 0; i < size(); ++i) {
            cout << locations[i] << " -> ";
            for (size_t j = 0; j < adj[i].size(); ++j) {
                cout << locations[adj[i][j]];
                if (j + 1 < adj[i].size()) cout << ", ";
            }
            cout << '\n';
        }
    }

    void displayAdjacencyMatrix() const {
        cout << "\n--- Adjacency Matrix (1 = road, 0 = no direct road) ---\n";
        cout << "       ";
        for (int i = 0; i < size(); ++i) cout << i + 1 << ' ';
        cout << '\n';

        for (int i = 0; i < size(); ++i) {
            cout << i + 1 << " (" << locations[i] << ")";
            if (locations[i].size() < 8) cout << '\t';
            else cout << '\t';
            for (int j = 0; j < size(); ++j) {
                bool connected = find(adj[i].begin(), adj[i].end(), j) != adj[i].end();
                cout << (connected ? 1 : 0) << ' ';
            }
            cout << '\n';
        }
    }

    bool bfsShortestPath(int source, int destination, vector<int>& path) const {
        vector<bool> visited(size(), false);
        vector<int> parent(size(), -1);
        queue<int> q;

        visited[source] = true;
        q.push(source);

        while (!q.empty()) {
            int current = q.front();
            q.pop();

            if (current == destination) break;

            for (int neighbour : adj[current]) {
                if (!visited[neighbour]) {
                    visited[neighbour] = true;
                    parent[neighbour] = current;
                    q.push(neighbour);
                }
            }
        }

        if (!visited[destination]) return false;

        for (int at = destination; at != -1; at = parent[at]) {
            path.push_back(at);
        }
        reverse(path.begin(), path.end());
        return true;
    }

    void displayBFSRoute(int source, int destination) const {
        vector<int> path;
        cout << "\n--- BFS Shortest Route ---\n";
        if (!bfsShortestPath(source, destination, path)) {
            cout << "No route exists between " << locations[source]
                 << " and " << locations[destination] << ".\n";
            return;
        }

        cout << "Route: ";
        for (size_t i = 0; i < path.size(); ++i) {
            cout << locations[path[i]];
            if (i + 1 < path.size()) cout << " -> ";
        }
        cout << "\nNumber of edges: " << path.size() - 1 << '\n';
        cout << "BFS finds a route with the minimum number of edges "
                "because this graph is unweighted.\n";
    }

    void displayDFSReachable(int source) const {
        vector<bool> visited(size(), false);
        cout << "\n--- DFS Reachable Locations ---\n";
        cout << "Starting from " << locations[source] << ":\n";
        dfsVisit(source, visited);
    }

    void displayReachableAndDisconnected(int source) const {
        vector<bool> visited(size(), false);
        queue<int> q;
        visited[source] = true;
        q.push(source);

        while (!q.empty()) {
            int current = q.front();
            q.pop();
            for (int neighbour : adj[current]) {
                if (!visited[neighbour]) {
                    visited[neighbour] = true;
                    q.push(neighbour);
                }
            }
        }

        cout << "\n--- Reachability Report ---\n";
        cout << "Reachable from " << locations[source] << ":\n";
        int reachableCount = 0;
        for (int i = 0; i < size(); ++i) {
            if (visited[i]) {
                cout << "  - " << locations[i] << '\n';
                ++reachableCount;
            }
        }

        cout << "Disconnected from this starting point:\n";
        bool foundDisconnected = false;
        for (int i = 0; i < size(); ++i) {
            if (!visited[i]) {
                cout << "  - " << locations[i] << '\n';
                foundDisconnected = true;
            }
        }
        if (!foundDisconnected) cout << "  None\n";
        cout << "Reachable count: " << reachableCount << " of " << size() << '\n';
    }

    bool runSelfTests() const {
        struct TestCase {
            string name;
            int source;
            int destination;
            bool expectedReachable;
            int expectedEdges;
        };

        const vector<TestCase> cases = {
            {"Direct route", 0, 6, true, 1},
            {"Multi-stop route", 0, 5, true, 3},
            {"Unreachable destination", 0, 9, false, -1}
        };

        cout << "\n--- Automated Test Cases ---\n";
        bool allPassed = true;

        for (const auto& test : cases) {
            vector<int> path;
            bool found = bfsShortestPath(test.source, test.destination, path);
            int edges = found ? static_cast<int>(path.size()) - 1 : -1;
            bool passed = (found == test.expectedReachable) &&
                          (!found || edges == test.expectedEdges);

            cout << test.name << ": " << (passed ? "PASS" : "FAIL") << '\n';
            cout << "  From: " << locations[test.source]
                 << " | To: " << locations[test.destination] << '\n';
            if (found) {
                cout << "  Actual route: ";
                for (size_t i = 0; i < path.size(); ++i) {
                    cout << locations[path[i]];
                    if (i + 1 < path.size()) cout << " -> ";
                }
                cout << "\n  Actual edges: " << edges << '\n';
            } else {
                cout << "  Actual result: No route exists\n";
            }
            cout << "  Expected: "
                 << (test.expectedReachable ? "Route exists" : "No route")
                 << (test.expectedReachable ? " with " + to_string(test.expectedEdges) + " edge(s)" : "")
                 << "\n";
            allPassed = allPassed && passed;
        }

        cout << "\nOverall result: " << (allPassed ? "ALL TESTS PASSED" : "SOME TESTS FAILED") << '\n';
        return allPassed;
    }
};

int readChoice(int minimum, int maximum) {
    int choice;
    while (true) {
        cout << "Enter your choice (" << minimum << "-" << maximum << "): ";
        if (cin >> choice && choice >= minimum && choice <= maximum) {
            return choice;
        }

        cout << "Invalid input. Please enter a number from "
             << minimum << " to " << maximum << ".\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

int selectLocation(const CampusGraph& campus, const string& prompt) {
    campus.displayLocations();
    cout << prompt << '\n';
    return readChoice(1, campus.size()) - 1;
}

int main() {
    CampusGraph campus;
    int choice;

    cout << "=========================================\n";
    cout << "       CAMPUS ROUTE FINDER USING GRAPHS\n";
    cout << "=========================================\n";

    do {
        cout << "\n============== MAIN MENU ==============\n";
        cout << "1. Display all campus locations\n";
        cout << "2. Display graph (Adjacency List)\n";
        cout << "3. Display graph (Adjacency Matrix)\n";
        cout << "4. Find shortest route using BFS\n";
        cout << "5. Display reachable locations using DFS\n";
        cout << "6. Display reachable and disconnected locations\n";
        cout << "7. Run automated test cases\n";
        cout << "8. Exit\n";

        choice = readChoice(1, 8);

        switch (choice) {
            case 1:
                campus.displayLocations();
                break;
            case 2:
                campus.displayAdjacencyList();
                break;
            case 3:
                campus.displayAdjacencyMatrix();
                break;
            case 4: {
                int source = selectLocation(campus, "Select SOURCE location:");
                int destination = selectLocation(campus, "Select DESTINATION location:");
                campus.displayBFSRoute(source, destination);
                break;
            }
            case 5: {
                int source = selectLocation(campus, "Select starting location for DFS:");
                campus.displayDFSReachable(source);
                break;
            }
            case 6: {
                int source = selectLocation(campus, "Select starting location:");
                campus.displayReachableAndDisconnected(source);
                break;
            }
            case 7:
                campus.runSelfTests();
                break;
            case 8:
                cout << "Thank you for using Campus Route Finder!\n";
                break;
        }
    } while (choice != 8);

    return 0;
}
